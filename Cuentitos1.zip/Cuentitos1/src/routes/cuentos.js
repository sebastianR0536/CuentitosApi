const express = require("express");
const router = express.Router(); //manejador de rutas de express
const cuentosSchema = require("../models/cuentos");
//Nuevo animal
router.post("/cuentos", (req, res) => {
    const Cuento = cuentosSchema(req.body);
    cuentos
        .save()
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});
module.exports = router;

//Consultar todos los animales
router.get("/cuentos", (req, res) => {
    cuentosSchema.find()
        .then((data) => res.json(data))
        .catch((error) => res.json({ message: error }));
});

